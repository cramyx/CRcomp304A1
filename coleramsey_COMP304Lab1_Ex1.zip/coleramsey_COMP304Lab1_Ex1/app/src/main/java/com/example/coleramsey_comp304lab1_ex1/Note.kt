package com.example.coleramsey_comp304lab1_ex1

data class Note(val title: String, val content: String)